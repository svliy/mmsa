class FP16_Optimizer(object):

    def __init__(self, *args, **kwargs):
        pass

    @property
    def optimizer(self):
        return self
    
    
def register_float_module(param, cast_args=True):
    print('register_float_module not implement')
    pass 


def init():
    print('init not implement')
    pass 