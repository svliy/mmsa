# mmsa
This is a code repositor for Multi Modal Sentiment Analysis.
